function mAP = fast_rcnn_test_val(conf, imdb, varargin)
% mAP = fast_rcnn_test(conf, imdb, roidb, varargin)
% --------------------------------------------------------
% Fast R-CNN
% Reimplementation based on Python Fast R-CNN (https://github.com/rbgirshick/fast-rcnn)
% Copyright (c) 2015, Shaoqing Ren
% Licensed under The MIT License [see LICENSE for details]
% --------------------------------------------------------

%% inputs
ip = inputParser;
ip.addParamValue('net_def_file', '', @isstr);
ip.addParamValue('net_file', '', @isstr);
ip.addParamValue('cache_name', '', @isstr);                                         
ip.addParamValue('suffix', '', @isstr);
ip.addParamValue('ignore_cache', false, @islogical);    
ip.parse(varargin{:});
opts = ip.Results;

mot_path = '/media/HDD1/hanulkim/MultiObjectTracking/Benchmark';
seq_path = fullfile(mot_path,'train');
seq_list = dir(seq_path);
seq_list = {seq_list(3:13).name};
val_idx = [2,5,7,10];
test_idx = 1:11;
ss_path = '/media/HDD1/hanulkim/MultiObjectTracking/Benchmark/train_ss';

%% set cache dir
cache_dir = fullfile(pwd, 'output', 'fast_rcnn_cachedir', opts.cache_name);
mkdir_if_missing(cache_dir);

%%  init log
timestamp = datestr(datevec(now()), 'yyyymmdd_HHMMSS');
mkdir_if_missing(fullfile(cache_dir, 'log'));
log_file = fullfile(cache_dir, 'log', ['test_', timestamp, '.txt']);
diary(log_file);

num_images = length(imdb);
num_classes = size(imdb(1).class,2);
  
%% testing 
% init caffe net
caffe_net = caffe.Net(opts.net_def_file, 'test');
caffe_net.copy_from(opts.net_file);

% set random seed
prev_rng = seed_rand(conf.rng_seed);
caffe.set_random_seed(conf.rng_seed);

% set gpu/cpu
if conf.use_gpu
  caffe.set_mode_gpu();
else
  caffe.set_mode_cpu();
end             

% determine the maximum number of rois in testing 
max_rois_num_in_gpu = check_gpu_memory(conf, caffe_net);

disp('opts:');
disp(opts);
disp('conf:');
disp(conf);

max_per_set = 40 * num_images;
max_per_image = 100;
thresh = -inf * ones(num_classes, 1);
top_scores = cell(num_classes, 1);
aboxes = cell(num_classes, 1);
box_inds = cell(num_classes, 1);
for i = 1:num_classes
  aboxes{i} = cell(length(imdb), 1);
  box_inds{i} = cell(length(imdb), 1);
end

count = 0;
th = 0.99:-0.01:0.50;
for n = val_idx
  im_path = fullfile(seq_path,seq_list{n},'img1');  
  im_list = dir(fullfile(im_path,'*.jpg'));
  im_list = {im_list.name};
  im = imread(fullfile(im_path,im_list{1}));
  [im_h,im_w,~] = size(im);

%   temp = dlmread(fullfile(seq_path,seq_list{n},'det','det.txt'));
%   x = temp(:,3);
%   y = temp(:,4);
%   w = temp(:,5);
%   h = temp(:,6);
%   public_dets = zeros(size(temp,1),5);
%   public_dets(:,1) = temp(:,1); 
%   public_dets(:,2) = max(1,round(x));
%   public_dets(:,3) = max(1,round(y));
%   public_dets(:,4) = min(im_w,round(x+w-1));
%   public_dets(:,5) = min(im_h,round(y+h-1));
  
  %ss_path = fullfile(mot_path,'test_ss',seq_list{n});
  boxes = cell(numel(im_list),50);
  scores = cell(numel(im_list),50);
  for t = 1:numel(im_list)
    fprintf('%s - %04d\n', seq_list{n},t);
    ss = importdata(fullfile(ss_path,sprintf('%06d.mat',t)));    
    xmin = ss(:,2); 
    ymin = ss(:,1); 
    xmax = ss(:,4); 
    ymax = ss(:,3);
    ss(:,1) = xmin; 
    ss(:,2) = ymin; 
    ss(:,3) = xmax; 
    ss(:,4) = ymax;
    %idx = logical(public_dets(:,1) == t);
    im = imread(fullfile(im_path,im_list{t}));
    [temp_boxes, temp_scores] = fast_rcnn_im_detect(conf, caffe_net, im, ss, max_rois_num_in_gpu);     
    
%     if sum(idx) > 0
%       ss = public_dets(idx,2:5);
%       im = imread(fullfile(im_path,im_list{t}));
%       [temp_boxes, temp_scores] = fast_rcnn_im_detect(conf, caffe_net, im, ss, max_rois_num_in_gpu); 
%     else
%       temp_boxes = zeros(0,4);
%       temp_scores = [];
%     end
       
    for k = 1:50
      idx = find(temp_scores >= th(k));
      if ~isempty(idx)
        [~, ord] = sort(temp_scores(idx), 'descend');
        ord = ord(1:min(length(ord), max_per_image));
        idx = idx(ord);
        ttemp_boxes = temp_boxes(idx,:);
        ttemp_scores = temp_scores(idx); 
        
        % NMS
        ttemp_state = zeros(numel(ttemp_scores),1);       
        for i = 1:numel(ttemp_scores)
          if ttemp_state(i) > 0, continue; end   
          ttemp_state(i) = 2;
          overlap = compute_overlap_(ttemp_boxes(i,:), ttemp_boxes);
          for j = i+1:numel(ttemp_scores)
            if overlap(j) > 0.5 && ttemp_state(j) < 1
              ttemp_state(j) = 1;
            end
          end
        end
        idx = logical(ttemp_state == 2);        
        boxes{t,k} = ttemp_boxes(idx,:);
        scores{t,k} = ttemp_scores(idx);         
        
      else
        boxes{t,k} = [];
        scores{t,k} = [];      
      end
    end       
  end
  
  for k = 1:50
    res_path = fullfile('output/trainval_vgg16/ss_val_30',seq_list{n});
    if ~exist(res_path, 'dir')
      mkdir(res_path);
    end
    det = boxes(:,k);
    save(fullfile(res_path,sprintf('%02d.mat',round(100*th(k)))),'det');    
  end  
end

caffe.reset_all(); 
rng(prev_rng);

end

% -----------------------------------------------------------------------------
function overlap = compute_overlap_(gt, boxes)
% -----------------------------------------------------------------------------
xmin = max(gt(1,1), boxes(:,1));
xmax = min(gt(1,3), boxes(:,3));
ymin = max(gt(1,2), boxes(:,2));
ymax = min(gt(1,4), boxes(:,4));
gt_w = gt(1,3)-gt(1,1);
gt_h = gt(1,4)-gt(1,2);
boxes_w = boxes(:,3)-boxes(:,1);
boxes_h = boxes(:,4)-boxes(:,2);

area1 = gt_w * gt_h;
area2 = boxes_w .* boxes_h;
i_area = max(0,(xmax-xmin)) .* max(0,(ymax-ymin));
u_area = area1 + area2 - i_area;
overlap = i_area ./ u_area;

end


function max_rois_num = check_gpu_memory(conf, caffe_net)
%%  try to determine the maximum number of rois
max_rois_num = 0;
for rois_num = 500:500:5000
    % generate pseudo testing data with max size
    im_blob = single(zeros(conf.max_size, conf.max_size, 3, 1));
    rois_blob = single(repmat([0; 0; 0; conf.max_size-1; conf.max_size-1], 1, rois_num));
    rois_blob = permute(rois_blob, [3, 4, 1, 2]);

    net_inputs = {im_blob, rois_blob};

    % Reshape net's input blobs
    caffe_net.reshape_as_input(net_inputs);

    caffe_net.forward(net_inputs);
    gpuInfo = gpuDevice();

    max_rois_num = rois_num;

    if gpuInfo.FreeMemory < 2 * 10^9  % 2GB for safety
        break;
    end
end

end
